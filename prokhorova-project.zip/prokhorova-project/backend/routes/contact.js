const express = require('express');
const router = express.Router();
const { sendContact } = require('../controllers/contact');

router.post('/', sendContact);

module.exports = router;