const products = [
  { id: 1, name: 'Крем "Сияние"', category: 'Уход за лицом', price: 4200, badge: 'хит' },
  { id: 2, name: 'Сыворотка "Возрождение"', category: 'Сыворотки', price: 5600, badge: 'новинка' },
  { id: 3, name: 'Тональный крем "Идеал"', category: 'Макияж', price: 3800, badge: null },
  { id: 4, name: 'Консилер "Совершенство"', category: 'Макияж', price: 2800, badge: null },
  { id: 5, name: 'Пудра "Матовость"', category: 'Макияж', price: 3200, badge: null },
  { id: 6, name: 'Румяна "Свежесть"', category: 'Макияж', price: 2400, badge: null },
  { id: 7, name: 'Тени "Гламур"', category: 'Макияж', price: 2600, badge: null },
  { id: 8, name: 'Подводка "Соблазн"', category: 'Макияж', price: 1900, badge: null },
  { id: 9, name: 'Тушь "Объем"', category: 'Макияж', price: 2200, badge: 'хит' },
  { id: 10, name: 'Помада "Шарм"', category: 'Макияж', price: 2700, badge: null },
  { id: 11, name: 'Блеск "Блеск"', category: 'Макияж', price: 1800, badge: null },
  { id: 12, name: 'Маска "Очищение"', category: 'Уход за лицом', price: 3400, badge: null },
  { id: 13, name: 'Скраб "Обновление"', category: 'Уход за лицом', price: 2900, badge: null },
  { id: 14, name: 'Лосьон "Тоник"', category: 'Уход за лицом', price: 2100, badge: null },
  { id: 15, name: 'Крем для рук "Нежность"', category: 'Уход за телом', price: 1600, badge: 'новинка' }
];

module.exports = products;