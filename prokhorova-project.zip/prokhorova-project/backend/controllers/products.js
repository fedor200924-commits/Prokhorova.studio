const products = require('../data/products');

exports.getAllProducts = (req, res) => {
  let { page = 1, limit = 10, category, search } = req.query;

  page = parseInt(page, 10) || 1;
  limit = parseInt(limit, 10) || 10;
  if (limit > 50) limit = 50;

  let filtered = [...products];

  if (category) {
    const categoryLower = category.toLowerCase();
    filtered = filtered.filter(p => p.category.toLowerCase() === categoryLower);
  }

  if (search) {
    const searchLower = search.toLowerCase().trim();
    filtered = filtered.filter(p => p.name.toLowerCase().includes(searchLower));
  }

  const total = filtered.length;
  const startIndex = (page - 1) * limit;
  const endIndex = Math.min(startIndex + limit, total);
  const paginatedProducts = filtered.slice(startIndex, endIndex);
  const totalPages = Math.ceil(total / limit);

  res.json({
    products: paginatedProducts,
    total,
    page,
    limit,
    totalPages,
    availableCategories: [...new Set(products.map(p => p.category))]
  });
};

exports.getProductById = (req, res) => {
  const id = parseInt(req.params.id);
  const product = products.find(p => p.id === id);
  if (!product) {
    return res.status(404).json({ error: 'Товар не найден' });
  }
  res.json(product);
};