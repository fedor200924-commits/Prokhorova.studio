exports.sendContact = (req, res) => {
  const { name, email, message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Заполните все поля' });
  }

  console.log(`📩 Сообщение от ${name} (${email}): ${message}`);

  // Здесь можно добавить отправку email или Telegram

  res.status(200).json({ message: 'Сообщение отправлено. Спасибо!' });
};