const { sendTelegramNotification } = require('../utils/telegram');

let orders = [];

exports.createOrder = (req, res) => {
  const { items, total, customer } = req.body;

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Корзина пуста' });
  }
  if (!total || typeof total !== 'number') {
    return res.status(400).json({ error: 'Неверная сумма' });
  }
  if (!customer || !customer.name || !customer.phone) {
    return res.status(400).json({ error: 'Укажите имя и телефон' });
  }

  const order = {
    id: orders.length + 1,
    items,
    total,
    customer,
    createdAt: new Date().toISOString(),
    status: 'new'
  };

  orders.push(order);

  // Отправка уведомления в Telegram (если настроено)
  sendTelegramNotification(order);

  res.status(201).json({
    message: 'Заказ успешно создан',
    orderId: order.id
  });
};

exports.getAllOrders = (req, res) => {
  res.json(orders);
};