// Заглушка для Telegram (можно будет настроить позже)
async function sendTelegramNotification(order) {
  console.log('📨 Уведомление в Telegram (заглушка):', order.id);
  // Здесь можно добавить реальную логику отправки
}

module.exports = { sendTelegramNotification };